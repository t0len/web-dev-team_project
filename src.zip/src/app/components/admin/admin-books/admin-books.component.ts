import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-books',
  imports: [],
  templateUrl: './admin-books.component.html',
  styleUrl: './admin-books.component.css'
})
export class AdminBooksComponent {

}
