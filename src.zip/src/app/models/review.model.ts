export interface Review {
    id: number;
    book_id: number;
    user: string;
    comment: string;
    rating: number;
}
  